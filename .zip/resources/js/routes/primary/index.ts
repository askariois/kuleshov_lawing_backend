import sorting from './sorting'
const primary = {
    sorting: Object.assign(sorting, sorting),
}

export default primary