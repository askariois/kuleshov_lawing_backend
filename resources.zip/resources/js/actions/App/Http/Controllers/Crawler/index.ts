import CrawlerController from './CrawlerController'
const Crawler = {
    CrawlerController: Object.assign(CrawlerController, CrawlerController),
}

export default Crawler