import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Crawler\CrawlerController::startScan
 * @see app/Http/Controllers/Crawler/CrawlerController.php:19
 * @route '/scan'
 */
export const startScan = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startScan.url(options),
    method: 'post',
})

startScan.definition = {
    methods: ["post"],
    url: '/scan',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Crawler\CrawlerController::startScan
 * @see app/Http/Controllers/Crawler/CrawlerController.php:19
 * @route '/scan'
 */
startScan.url = (options?: RouteQueryOptions) => {
    return startScan.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crawler\CrawlerController::startScan
 * @see app/Http/Controllers/Crawler/CrawlerController.php:19
 * @route '/scan'
 */
startScan.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startScan.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Crawler\CrawlerController::startScan
 * @see app/Http/Controllers/Crawler/CrawlerController.php:19
 * @route '/scan'
 */
    const startScanForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: startScan.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Crawler\CrawlerController::startScan
 * @see app/Http/Controllers/Crawler/CrawlerController.php:19
 * @route '/scan'
 */
        startScanForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: startScan.url(options),
            method: 'post',
        })
    
    startScan.form = startScanForm
/**
* @see \App\Http\Controllers\Crawler\CrawlerController::startScan_2
 * @see app/Http/Controllers/Crawler/CrawlerController.php:36
 * @route '/scan_2'
 */
export const startScan_2 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startScan_2.url(options),
    method: 'post',
})

startScan_2.definition = {
    methods: ["post"],
    url: '/scan_2',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Crawler\CrawlerController::startScan_2
 * @see app/Http/Controllers/Crawler/CrawlerController.php:36
 * @route '/scan_2'
 */
startScan_2.url = (options?: RouteQueryOptions) => {
    return startScan_2.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crawler\CrawlerController::startScan_2
 * @see app/Http/Controllers/Crawler/CrawlerController.php:36
 * @route '/scan_2'
 */
startScan_2.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startScan_2.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Crawler\CrawlerController::startScan_2
 * @see app/Http/Controllers/Crawler/CrawlerController.php:36
 * @route '/scan_2'
 */
    const startScan_2Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: startScan_2.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Crawler\CrawlerController::startScan_2
 * @see app/Http/Controllers/Crawler/CrawlerController.php:36
 * @route '/scan_2'
 */
        startScan_2Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: startScan_2.url(options),
            method: 'post',
        })
    
    startScan_2.form = startScan_2Form
/**
* @see \App\Http\Controllers\Crawler\CrawlerController::getProgress
 * @see app/Http/Controllers/Crawler/CrawlerController.php:0
 * @route '/progress'
 */
export const getProgress = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getProgress.url(options),
    method: 'get',
})

getProgress.definition = {
    methods: ["get","head"],
    url: '/progress',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Crawler\CrawlerController::getProgress
 * @see app/Http/Controllers/Crawler/CrawlerController.php:0
 * @route '/progress'
 */
getProgress.url = (options?: RouteQueryOptions) => {
    return getProgress.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crawler\CrawlerController::getProgress
 * @see app/Http/Controllers/Crawler/CrawlerController.php:0
 * @route '/progress'
 */
getProgress.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getProgress.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Crawler\CrawlerController::getProgress
 * @see app/Http/Controllers/Crawler/CrawlerController.php:0
 * @route '/progress'
 */
getProgress.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getProgress.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Crawler\CrawlerController::getProgress
 * @see app/Http/Controllers/Crawler/CrawlerController.php:0
 * @route '/progress'
 */
    const getProgressForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getProgress.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Crawler\CrawlerController::getProgress
 * @see app/Http/Controllers/Crawler/CrawlerController.php:0
 * @route '/progress'
 */
        getProgressForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getProgress.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Crawler\CrawlerController::getProgress
 * @see app/Http/Controllers/Crawler/CrawlerController.php:0
 * @route '/progress'
 */
        getProgressForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getProgress.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getProgress.form = getProgressForm
const CrawlerController = { startScan, startScan_2, getProgress }

export default CrawlerController