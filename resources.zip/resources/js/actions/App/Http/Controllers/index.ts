import Auth from './Auth'
import Projects from './Projects'
import Crawler from './Crawler'
import Images from './Images'
import Settings from './Settings'
const Controllers = {
    Auth: Object.assign(Auth, Auth),
Projects: Object.assign(Projects, Projects),
Crawler: Object.assign(Crawler, Crawler),
Images: Object.assign(Images, Images),
Settings: Object.assign(Settings, Settings),
}

export default Controllers