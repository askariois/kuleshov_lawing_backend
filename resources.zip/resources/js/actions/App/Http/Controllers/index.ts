import Auth from './Auth'
import Images from './Images'
import Projects from './Projects'
import Crawler from './Crawler'
import Sort from './Sort'
import GenerateImageController from './GenerateImageController'
import Settings from './Settings'
const Controllers = {
    Auth: Object.assign(Auth, Auth),
Images: Object.assign(Images, Images),
Projects: Object.assign(Projects, Projects),
Crawler: Object.assign(Crawler, Crawler),
Sort: Object.assign(Sort, Sort),
GenerateImageController: Object.assign(GenerateImageController, GenerateImageController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers