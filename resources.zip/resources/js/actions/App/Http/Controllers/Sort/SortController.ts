import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Sort\SortController::sort
 * @see app/Http/Controllers/Sort/SortController.php:18
 * @route '/primary-sorting/{id}'
 */
export const sort = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sort.url(args, options),
    method: 'get',
})

sort.definition = {
    methods: ["get","head"],
    url: '/primary-sorting/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Sort\SortController::sort
 * @see app/Http/Controllers/Sort/SortController.php:18
 * @route '/primary-sorting/{id}'
 */
sort.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return sort.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sort\SortController::sort
 * @see app/Http/Controllers/Sort/SortController.php:18
 * @route '/primary-sorting/{id}'
 */
sort.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sort.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Sort\SortController::sort
 * @see app/Http/Controllers/Sort/SortController.php:18
 * @route '/primary-sorting/{id}'
 */
sort.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sort.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Sort\SortController::sort
 * @see app/Http/Controllers/Sort/SortController.php:18
 * @route '/primary-sorting/{id}'
 */
    const sortForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: sort.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Sort\SortController::sort
 * @see app/Http/Controllers/Sort/SortController.php:18
 * @route '/primary-sorting/{id}'
 */
        sortForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sort.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Sort\SortController::sort
 * @see app/Http/Controllers/Sort/SortController.php:18
 * @route '/primary-sorting/{id}'
 */
        sortForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sort.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    sort.form = sortForm
/**
* @see \App\Http\Controllers\Sort\SortController::storeSorting
 * @see app/Http/Controllers/Sort/SortController.php:52
 * @route '/primary-sorting/{id}/sort'
 */
export const storeSorting = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSorting.url(args, options),
    method: 'post',
})

storeSorting.definition = {
    methods: ["post"],
    url: '/primary-sorting/{id}/sort',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Sort\SortController::storeSorting
 * @see app/Http/Controllers/Sort/SortController.php:52
 * @route '/primary-sorting/{id}/sort'
 */
storeSorting.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return storeSorting.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sort\SortController::storeSorting
 * @see app/Http/Controllers/Sort/SortController.php:52
 * @route '/primary-sorting/{id}/sort'
 */
storeSorting.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSorting.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Sort\SortController::storeSorting
 * @see app/Http/Controllers/Sort/SortController.php:52
 * @route '/primary-sorting/{id}/sort'
 */
    const storeSortingForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeSorting.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Sort\SortController::storeSorting
 * @see app/Http/Controllers/Sort/SortController.php:52
 * @route '/primary-sorting/{id}/sort'
 */
        storeSortingForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeSorting.url(args, options),
            method: 'post',
        })
    
    storeSorting.form = storeSortingForm
/**
* @see \App\Http\Controllers\Sort\SortController::sort_secondary
 * @see app/Http/Controllers/Sort/SortController.php:103
 * @route '/secondary-sorting/{id}'
 */
export const sort_secondary = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sort_secondary.url(args, options),
    method: 'get',
})

sort_secondary.definition = {
    methods: ["get","head"],
    url: '/secondary-sorting/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Sort\SortController::sort_secondary
 * @see app/Http/Controllers/Sort/SortController.php:103
 * @route '/secondary-sorting/{id}'
 */
sort_secondary.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return sort_secondary.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sort\SortController::sort_secondary
 * @see app/Http/Controllers/Sort/SortController.php:103
 * @route '/secondary-sorting/{id}'
 */
sort_secondary.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sort_secondary.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Sort\SortController::sort_secondary
 * @see app/Http/Controllers/Sort/SortController.php:103
 * @route '/secondary-sorting/{id}'
 */
sort_secondary.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sort_secondary.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Sort\SortController::sort_secondary
 * @see app/Http/Controllers/Sort/SortController.php:103
 * @route '/secondary-sorting/{id}'
 */
    const sort_secondaryForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: sort_secondary.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Sort\SortController::sort_secondary
 * @see app/Http/Controllers/Sort/SortController.php:103
 * @route '/secondary-sorting/{id}'
 */
        sort_secondaryForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sort_secondary.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Sort\SortController::sort_secondary
 * @see app/Http/Controllers/Sort/SortController.php:103
 * @route '/secondary-sorting/{id}'
 */
        sort_secondaryForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sort_secondary.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    sort_secondary.form = sort_secondaryForm
/**
* @see \App\Http\Controllers\Sort\SortController::checkDuplicates
 * @see app/Http/Controllers/Sort/SortController.php:133
 * @route '/secondary-sorting/{image}/check-duplicates'
 */
export const checkDuplicates = (args: { image: number | { id: number } } | [image: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkDuplicates.url(args, options),
    method: 'post',
})

checkDuplicates.definition = {
    methods: ["post"],
    url: '/secondary-sorting/{image}/check-duplicates',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Sort\SortController::checkDuplicates
 * @see app/Http/Controllers/Sort/SortController.php:133
 * @route '/secondary-sorting/{image}/check-duplicates'
 */
checkDuplicates.url = (args: { image: number | { id: number } } | [image: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { image: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { image: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    image: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        image: typeof args.image === 'object'
                ? args.image.id
                : args.image,
                }

    return checkDuplicates.definition.url
            .replace('{image}', parsedArgs.image.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sort\SortController::checkDuplicates
 * @see app/Http/Controllers/Sort/SortController.php:133
 * @route '/secondary-sorting/{image}/check-duplicates'
 */
checkDuplicates.post = (args: { image: number | { id: number } } | [image: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkDuplicates.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Sort\SortController::checkDuplicates
 * @see app/Http/Controllers/Sort/SortController.php:133
 * @route '/secondary-sorting/{image}/check-duplicates'
 */
    const checkDuplicatesForm = (args: { image: number | { id: number } } | [image: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: checkDuplicates.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Sort\SortController::checkDuplicates
 * @see app/Http/Controllers/Sort/SortController.php:133
 * @route '/secondary-sorting/{image}/check-duplicates'
 */
        checkDuplicatesForm.post = (args: { image: number | { id: number } } | [image: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: checkDuplicates.url(args, options),
            method: 'post',
        })
    
    checkDuplicates.form = checkDuplicatesForm
/**
* @see \App\Http\Controllers\Sort\SortController::runAutoFree
 * @see app/Http/Controllers/Sort/SortController.php:153
 * @route '/secondary-free'
 */
export const runAutoFree = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: runAutoFree.url(options),
    method: 'get',
})

runAutoFree.definition = {
    methods: ["get","head"],
    url: '/secondary-free',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Sort\SortController::runAutoFree
 * @see app/Http/Controllers/Sort/SortController.php:153
 * @route '/secondary-free'
 */
runAutoFree.url = (options?: RouteQueryOptions) => {
    return runAutoFree.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sort\SortController::runAutoFree
 * @see app/Http/Controllers/Sort/SortController.php:153
 * @route '/secondary-free'
 */
runAutoFree.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: runAutoFree.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Sort\SortController::runAutoFree
 * @see app/Http/Controllers/Sort/SortController.php:153
 * @route '/secondary-free'
 */
runAutoFree.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: runAutoFree.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Sort\SortController::runAutoFree
 * @see app/Http/Controllers/Sort/SortController.php:153
 * @route '/secondary-free'
 */
    const runAutoFreeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: runAutoFree.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Sort\SortController::runAutoFree
 * @see app/Http/Controllers/Sort/SortController.php:153
 * @route '/secondary-free'
 */
        runAutoFreeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: runAutoFree.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Sort\SortController::runAutoFree
 * @see app/Http/Controllers/Sort/SortController.php:153
 * @route '/secondary-free'
 */
        runAutoFreeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: runAutoFree.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    runAutoFree.form = runAutoFreeForm
const SortController = { sort, storeSorting, sort_secondary, checkDuplicates, runAutoFree }

export default SortController