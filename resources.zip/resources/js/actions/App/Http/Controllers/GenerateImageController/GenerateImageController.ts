import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\GenerateImageController\GenerateImageController::generate
 * @see app/Http/Controllers/GenerateImageController/GenerateImageController.php:18
 * @route '/generate-img/{projectId}'
 */
export const generate = (args: { projectId: string | number } | [projectId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(args, options),
    method: 'post',
})

generate.definition = {
    methods: ["post"],
    url: '/generate-img/{projectId}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\GenerateImageController\GenerateImageController::generate
 * @see app/Http/Controllers/GenerateImageController/GenerateImageController.php:18
 * @route '/generate-img/{projectId}'
 */
generate.url = (args: { projectId: string | number } | [projectId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { projectId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    projectId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        projectId: args.projectId,
                }

    return generate.definition.url
            .replace('{projectId}', parsedArgs.projectId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GenerateImageController\GenerateImageController::generate
 * @see app/Http/Controllers/GenerateImageController/GenerateImageController.php:18
 * @route '/generate-img/{projectId}'
 */
generate.post = (args: { projectId: string | number } | [projectId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\GenerateImageController\GenerateImageController::generate
 * @see app/Http/Controllers/GenerateImageController/GenerateImageController.php:18
 * @route '/generate-img/{projectId}'
 */
    const generateForm = (args: { projectId: string | number } | [projectId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\GenerateImageController\GenerateImageController::generate
 * @see app/Http/Controllers/GenerateImageController/GenerateImageController.php:18
 * @route '/generate-img/{projectId}'
 */
        generateForm.post = (args: { projectId: string | number } | [projectId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generate.url(args, options),
            method: 'post',
        })
    
    generate.form = generateForm
const GenerateImageController = { generate }

export default GenerateImageController