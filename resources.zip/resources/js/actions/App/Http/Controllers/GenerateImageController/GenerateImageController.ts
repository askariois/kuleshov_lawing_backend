import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\GenerateImageController\GenerateImageController::generate
 * @see app/Http/Controllers/GenerateImageController/GenerateImageController.php:17
 * @route '/generate-img/{projectId}'
 */
export const generate = (args: { projectId: string | number } | [projectId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(args, options),
    method: 'post',
})

generate.definition = {
    methods: ["post"],
    url: '/generate-img/{projectId}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\GenerateImageController\GenerateImageController::generate
 * @see app/Http/Controllers/GenerateImageController/GenerateImageController.php:17
 * @route '/generate-img/{projectId}'
 */
generate.url = (args: { projectId: string | number } | [projectId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { projectId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    projectId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        projectId: args.projectId,
                }

    return generate.definition.url
            .replace('{projectId}', parsedArgs.projectId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GenerateImageController\GenerateImageController::generate
 * @see app/Http/Controllers/GenerateImageController/GenerateImageController.php:17
 * @route '/generate-img/{projectId}'
 */
generate.post = (args: { projectId: string | number } | [projectId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\GenerateImageController\GenerateImageController::generate
 * @see app/Http/Controllers/GenerateImageController/GenerateImageController.php:17
 * @route '/generate-img/{projectId}'
 */
    const generateForm = (args: { projectId: string | number } | [projectId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\GenerateImageController\GenerateImageController::generate
 * @see app/Http/Controllers/GenerateImageController/GenerateImageController.php:17
 * @route '/generate-img/{projectId}'
 */
        generateForm.post = (args: { projectId: string | number } | [projectId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generate.url(args, options),
            method: 'post',
        })
    
    generate.form = generateForm
/**
* @see \App\Http\Controllers\GenerateImageController\GenerateImageController::index
 * @see app/Http/Controllers/GenerateImageController/GenerateImageController.php:0
 * @route '/generate-img/{image}'
 */
export const index = (args: { image: string | number } | [image: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/generate-img/{image}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GenerateImageController\GenerateImageController::index
 * @see app/Http/Controllers/GenerateImageController/GenerateImageController.php:0
 * @route '/generate-img/{image}'
 */
index.url = (args: { image: string | number } | [image: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { image: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    image: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        image: args.image,
                }

    return index.definition.url
            .replace('{image}', parsedArgs.image.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GenerateImageController\GenerateImageController::index
 * @see app/Http/Controllers/GenerateImageController/GenerateImageController.php:0
 * @route '/generate-img/{image}'
 */
index.get = (args: { image: string | number } | [image: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\GenerateImageController\GenerateImageController::index
 * @see app/Http/Controllers/GenerateImageController/GenerateImageController.php:0
 * @route '/generate-img/{image}'
 */
index.head = (args: { image: string | number } | [image: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\GenerateImageController\GenerateImageController::index
 * @see app/Http/Controllers/GenerateImageController/GenerateImageController.php:0
 * @route '/generate-img/{image}'
 */
    const indexForm = (args: { image: string | number } | [image: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\GenerateImageController\GenerateImageController::index
 * @see app/Http/Controllers/GenerateImageController/GenerateImageController.php:0
 * @route '/generate-img/{image}'
 */
        indexForm.get = (args: { image: string | number } | [image: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\GenerateImageController\GenerateImageController::index
 * @see app/Http/Controllers/GenerateImageController/GenerateImageController.php:0
 * @route '/generate-img/{image}'
 */
        indexForm.head = (args: { image: string | number } | [image: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const GenerateImageController = { generate, index }

export default GenerateImageController