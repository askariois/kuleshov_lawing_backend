import ProjectsController from './ProjectsController'
const Projects = {
    ProjectsController: Object.assign(ProjectsController, ProjectsController),
}

export default Projects