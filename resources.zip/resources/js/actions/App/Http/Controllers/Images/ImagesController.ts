import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Images\ImagesController::index
 * @see app/Http/Controllers/Images/ImagesController.php:15
 * @route '/images/{id}'
 */
export const index = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/images/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Images\ImagesController::index
 * @see app/Http/Controllers/Images/ImagesController.php:15
 * @route '/images/{id}'
 */
index.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return index.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Images\ImagesController::index
 * @see app/Http/Controllers/Images/ImagesController.php:15
 * @route '/images/{id}'
 */
index.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Images\ImagesController::index
 * @see app/Http/Controllers/Images/ImagesController.php:15
 * @route '/images/{id}'
 */
index.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Images\ImagesController::index
 * @see app/Http/Controllers/Images/ImagesController.php:15
 * @route '/images/{id}'
 */
    const indexForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Images\ImagesController::index
 * @see app/Http/Controllers/Images/ImagesController.php:15
 * @route '/images/{id}'
 */
        indexForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Images\ImagesController::index
 * @see app/Http/Controllers/Images/ImagesController.php:15
 * @route '/images/{id}'
 */
        indexForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Images\ImagesController::primary_sorting
 * @see app/Http/Controllers/Images/ImagesController.php:41
 * @route '/primary-sorting/{id}'
 */
export const primary_sorting = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: primary_sorting.url(args, options),
    method: 'get',
})

primary_sorting.definition = {
    methods: ["get","head"],
    url: '/primary-sorting/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Images\ImagesController::primary_sorting
 * @see app/Http/Controllers/Images/ImagesController.php:41
 * @route '/primary-sorting/{id}'
 */
primary_sorting.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return primary_sorting.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Images\ImagesController::primary_sorting
 * @see app/Http/Controllers/Images/ImagesController.php:41
 * @route '/primary-sorting/{id}'
 */
primary_sorting.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: primary_sorting.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Images\ImagesController::primary_sorting
 * @see app/Http/Controllers/Images/ImagesController.php:41
 * @route '/primary-sorting/{id}'
 */
primary_sorting.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: primary_sorting.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Images\ImagesController::primary_sorting
 * @see app/Http/Controllers/Images/ImagesController.php:41
 * @route '/primary-sorting/{id}'
 */
    const primary_sortingForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: primary_sorting.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Images\ImagesController::primary_sorting
 * @see app/Http/Controllers/Images/ImagesController.php:41
 * @route '/primary-sorting/{id}'
 */
        primary_sortingForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: primary_sorting.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Images\ImagesController::primary_sorting
 * @see app/Http/Controllers/Images/ImagesController.php:41
 * @route '/primary-sorting/{id}'
 */
        primary_sortingForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: primary_sorting.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    primary_sorting.form = primary_sortingForm
/**
* @see \App\Http\Controllers\Images\ImagesController::primarySort
 * @see app/Http/Controllers/Images/ImagesController.php:58
 * @route '/primary-sorting/{id}/sort'
 */
export const primarySort = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: primarySort.url(args, options),
    method: 'post',
})

primarySort.definition = {
    methods: ["post"],
    url: '/primary-sorting/{id}/sort',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Images\ImagesController::primarySort
 * @see app/Http/Controllers/Images/ImagesController.php:58
 * @route '/primary-sorting/{id}/sort'
 */
primarySort.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return primarySort.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Images\ImagesController::primarySort
 * @see app/Http/Controllers/Images/ImagesController.php:58
 * @route '/primary-sorting/{id}/sort'
 */
primarySort.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: primarySort.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Images\ImagesController::primarySort
 * @see app/Http/Controllers/Images/ImagesController.php:58
 * @route '/primary-sorting/{id}/sort'
 */
    const primarySortForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: primarySort.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Images\ImagesController::primarySort
 * @see app/Http/Controllers/Images/ImagesController.php:58
 * @route '/primary-sorting/{id}/sort'
 */
        primarySortForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: primarySort.url(args, options),
            method: 'post',
        })
    
    primarySort.form = primarySortForm
/**
* @see \App\Http\Controllers\Images\ImagesController::customer_request
 * @see app/Http/Controllers/Images/ImagesController.php:31
 * @route '/customer_request/{id}'
 */
export const customer_request = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: customer_request.url(args, options),
    method: 'get',
})

customer_request.definition = {
    methods: ["get","head"],
    url: '/customer_request/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Images\ImagesController::customer_request
 * @see app/Http/Controllers/Images/ImagesController.php:31
 * @route '/customer_request/{id}'
 */
customer_request.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return customer_request.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Images\ImagesController::customer_request
 * @see app/Http/Controllers/Images/ImagesController.php:31
 * @route '/customer_request/{id}'
 */
customer_request.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: customer_request.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Images\ImagesController::customer_request
 * @see app/Http/Controllers/Images/ImagesController.php:31
 * @route '/customer_request/{id}'
 */
customer_request.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: customer_request.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Images\ImagesController::customer_request
 * @see app/Http/Controllers/Images/ImagesController.php:31
 * @route '/customer_request/{id}'
 */
    const customer_requestForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: customer_request.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Images\ImagesController::customer_request
 * @see app/Http/Controllers/Images/ImagesController.php:31
 * @route '/customer_request/{id}'
 */
        customer_requestForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: customer_request.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Images\ImagesController::customer_request
 * @see app/Http/Controllers/Images/ImagesController.php:31
 * @route '/customer_request/{id}'
 */
        customer_requestForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: customer_request.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    customer_request.form = customer_requestForm
const ImagesController = { index, primary_sorting, primarySort, customer_request }

export default ImagesController