// components/project-settings/tabs/SitemapsTab.tsx
export function SitemapsTab() {
   return (
      <div className="pt-6 border-t text-center py-12 text-muted-foreground">
         <p className="text-lg">Sitemaps — в разработке</p>
         <p className="text-sm mt-2">Скоро здесь будет управление картой сайта</p>
      </div>
   )
}