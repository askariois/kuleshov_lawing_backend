import React from "react";
import copy_link from "../../../images/copy_link.svg";

function CopyLink() {
  return (
    <div>
      <img src={copy_link} className="ml-2" />
    </div>
  );
}

export default CopyLink;
