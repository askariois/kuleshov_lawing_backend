
import Single from '@/components/features/single/single';


export default function SinglePrimary() {
   return (
      <Single />
   )
}
