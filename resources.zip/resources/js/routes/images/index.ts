import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Sort\SortController::checkDuplicates
 * @see app/Http/Controllers/Sort/SortController.php:133
 * @route '/secondary-sorting/{image}/check-duplicates'
 */
export const checkDuplicates = (args: { image: number | { id: number } } | [image: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkDuplicates.url(args, options),
    method: 'post',
})

checkDuplicates.definition = {
    methods: ["post"],
    url: '/secondary-sorting/{image}/check-duplicates',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Sort\SortController::checkDuplicates
 * @see app/Http/Controllers/Sort/SortController.php:133
 * @route '/secondary-sorting/{image}/check-duplicates'
 */
checkDuplicates.url = (args: { image: number | { id: number } } | [image: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { image: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { image: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    image: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        image: typeof args.image === 'object'
                ? args.image.id
                : args.image,
                }

    return checkDuplicates.definition.url
            .replace('{image}', parsedArgs.image.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sort\SortController::checkDuplicates
 * @see app/Http/Controllers/Sort/SortController.php:133
 * @route '/secondary-sorting/{image}/check-duplicates'
 */
checkDuplicates.post = (args: { image: number | { id: number } } | [image: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkDuplicates.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Sort\SortController::checkDuplicates
 * @see app/Http/Controllers/Sort/SortController.php:133
 * @route '/secondary-sorting/{image}/check-duplicates'
 */
    const checkDuplicatesForm = (args: { image: number | { id: number } } | [image: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: checkDuplicates.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Sort\SortController::checkDuplicates
 * @see app/Http/Controllers/Sort/SortController.php:133
 * @route '/secondary-sorting/{image}/check-duplicates'
 */
        checkDuplicatesForm.post = (args: { image: number | { id: number } } | [image: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: checkDuplicates.url(args, options),
            method: 'post',
        })
    
    checkDuplicates.form = checkDuplicatesForm
/**
* @see \App\Http\Controllers\Sort\SortController::autoFreeReplace
 * @see app/Http/Controllers/Sort/SortController.php:153
 * @route '/secondary-free'
 */
export const autoFreeReplace = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: autoFreeReplace.url(options),
    method: 'get',
})

autoFreeReplace.definition = {
    methods: ["get","head"],
    url: '/secondary-free',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Sort\SortController::autoFreeReplace
 * @see app/Http/Controllers/Sort/SortController.php:153
 * @route '/secondary-free'
 */
autoFreeReplace.url = (options?: RouteQueryOptions) => {
    return autoFreeReplace.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sort\SortController::autoFreeReplace
 * @see app/Http/Controllers/Sort/SortController.php:153
 * @route '/secondary-free'
 */
autoFreeReplace.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: autoFreeReplace.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Sort\SortController::autoFreeReplace
 * @see app/Http/Controllers/Sort/SortController.php:153
 * @route '/secondary-free'
 */
autoFreeReplace.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: autoFreeReplace.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Sort\SortController::autoFreeReplace
 * @see app/Http/Controllers/Sort/SortController.php:153
 * @route '/secondary-free'
 */
    const autoFreeReplaceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: autoFreeReplace.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Sort\SortController::autoFreeReplace
 * @see app/Http/Controllers/Sort/SortController.php:153
 * @route '/secondary-free'
 */
        autoFreeReplaceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: autoFreeReplace.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Sort\SortController::autoFreeReplace
 * @see app/Http/Controllers/Sort/SortController.php:153
 * @route '/secondary-free'
 */
        autoFreeReplaceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: autoFreeReplace.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    autoFreeReplace.form = autoFreeReplaceForm
const images = {
    checkDuplicates: Object.assign(checkDuplicates, checkDuplicates),
autoFreeReplace: Object.assign(autoFreeReplace, autoFreeReplace),
}

export default images