import CrawlerController from './CrawlerController'
import CrawlerLogsController from './CrawlerLogsController'
const Crawler = {
    CrawlerController: Object.assign(CrawlerController, CrawlerController),
CrawlerLogsController: Object.assign(CrawlerLogsController, CrawlerLogsController),
}

export default Crawler