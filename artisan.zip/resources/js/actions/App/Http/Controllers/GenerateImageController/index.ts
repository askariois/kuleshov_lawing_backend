import GenerateImageController from './GenerateImageController'
const GenerateImageController = {
    GenerateImageController: Object.assign(GenerateImageController, GenerateImageController),
}

export default GenerateImageController