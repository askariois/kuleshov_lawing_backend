import ImagesController from './ImagesController'
const Images = {
    ImagesController: Object.assign(ImagesController, ImagesController),
}

export default Images