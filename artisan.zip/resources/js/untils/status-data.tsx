export const statusData = [
   {
      id: 0, name: "all", label: "Все"
   },
   {
      id: 1, name: "raw", label: "Необработанное"
   },
   {
      id: 2, name: "design", label: "Обработано"
   },
   {
      id: 3, name: "author", label: "Авторское"
   }, {
      id: 4, name: "replaced", label: "Заменено"
   },
   {
      id: 5, name: "clent", label: "Запрос клиенту"
   },
   {
      id: 6, name: "free", label: "Бесплатное"
   },

   {
      id: 7, name: "process", label: "В процессе"
   },
   {
      id: 8, name: "ToR", label: "В ТЗ"
   },
   {
      id: 9, name: "queue", label: "Очередь на генерацию"
   },
]