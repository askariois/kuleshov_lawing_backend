import sorting from './sorting'
const secondary = {
    sorting: Object.assign(sorting, sorting),
}

export default secondary