import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Images\ImagesController::verification
 * @see app/Http/Controllers/Images/ImagesController.php:0
 * @route '/verification'
 */
export const verification = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verification.url(options),
    method: 'get',
})

verification.definition = {
    methods: ["get","head"],
    url: '/verification',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Images\ImagesController::verification
 * @see app/Http/Controllers/Images/ImagesController.php:0
 * @route '/verification'
 */
verification.url = (options?: RouteQueryOptions) => {
    return verification.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Images\ImagesController::verification
 * @see app/Http/Controllers/Images/ImagesController.php:0
 * @route '/verification'
 */
verification.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verification.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Images\ImagesController::verification
 * @see app/Http/Controllers/Images/ImagesController.php:0
 * @route '/verification'
 */
verification.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: verification.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Images\ImagesController::verification
 * @see app/Http/Controllers/Images/ImagesController.php:0
 * @route '/verification'
 */
    const verificationForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: verification.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Images\ImagesController::verification
 * @see app/Http/Controllers/Images/ImagesController.php:0
 * @route '/verification'
 */
        verificationForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: verification.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Images\ImagesController::verification
 * @see app/Http/Controllers/Images/ImagesController.php:0
 * @route '/verification'
 */
        verificationForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: verification.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    verification.form = verificationForm
/**
* @see \App\Http\Controllers\Images\ImagesController::index
 * @see app/Http/Controllers/Images/ImagesController.php:15
 * @route '/images/{id}'
 */
export const index = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/images/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Images\ImagesController::index
 * @see app/Http/Controllers/Images/ImagesController.php:15
 * @route '/images/{id}'
 */
index.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return index.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Images\ImagesController::index
 * @see app/Http/Controllers/Images/ImagesController.php:15
 * @route '/images/{id}'
 */
index.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Images\ImagesController::index
 * @see app/Http/Controllers/Images/ImagesController.php:15
 * @route '/images/{id}'
 */
index.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Images\ImagesController::index
 * @see app/Http/Controllers/Images/ImagesController.php:15
 * @route '/images/{id}'
 */
    const indexForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Images\ImagesController::index
 * @see app/Http/Controllers/Images/ImagesController.php:15
 * @route '/images/{id}'
 */
        indexForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Images\ImagesController::index
 * @see app/Http/Controllers/Images/ImagesController.php:15
 * @route '/images/{id}'
 */
        indexForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Images\ImagesController::customer_request
 * @see app/Http/Controllers/Images/ImagesController.php:72
 * @route '/customer_request/{id}'
 */
export const customer_request = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: customer_request.url(args, options),
    method: 'get',
})

customer_request.definition = {
    methods: ["get","head"],
    url: '/customer_request/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Images\ImagesController::customer_request
 * @see app/Http/Controllers/Images/ImagesController.php:72
 * @route '/customer_request/{id}'
 */
customer_request.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return customer_request.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Images\ImagesController::customer_request
 * @see app/Http/Controllers/Images/ImagesController.php:72
 * @route '/customer_request/{id}'
 */
customer_request.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: customer_request.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Images\ImagesController::customer_request
 * @see app/Http/Controllers/Images/ImagesController.php:72
 * @route '/customer_request/{id}'
 */
customer_request.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: customer_request.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Images\ImagesController::customer_request
 * @see app/Http/Controllers/Images/ImagesController.php:72
 * @route '/customer_request/{id}'
 */
    const customer_requestForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: customer_request.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Images\ImagesController::customer_request
 * @see app/Http/Controllers/Images/ImagesController.php:72
 * @route '/customer_request/{id}'
 */
        customer_requestForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: customer_request.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Images\ImagesController::customer_request
 * @see app/Http/Controllers/Images/ImagesController.php:72
 * @route '/customer_request/{id}'
 */
        customer_requestForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: customer_request.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    customer_request.form = customer_requestForm
/**
* @see \App\Http\Controllers\Images\ImagesController::tor
 * @see app/Http/Controllers/Images/ImagesController.php:82
 * @route '/tor/{id}'
 */
export const tor = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tor.url(args, options),
    method: 'get',
})

tor.definition = {
    methods: ["get","head"],
    url: '/tor/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Images\ImagesController::tor
 * @see app/Http/Controllers/Images/ImagesController.php:82
 * @route '/tor/{id}'
 */
tor.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return tor.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Images\ImagesController::tor
 * @see app/Http/Controllers/Images/ImagesController.php:82
 * @route '/tor/{id}'
 */
tor.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tor.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Images\ImagesController::tor
 * @see app/Http/Controllers/Images/ImagesController.php:82
 * @route '/tor/{id}'
 */
tor.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: tor.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Images\ImagesController::tor
 * @see app/Http/Controllers/Images/ImagesController.php:82
 * @route '/tor/{id}'
 */
    const torForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: tor.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Images\ImagesController::tor
 * @see app/Http/Controllers/Images/ImagesController.php:82
 * @route '/tor/{id}'
 */
        torForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: tor.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Images\ImagesController::tor
 * @see app/Http/Controllers/Images/ImagesController.php:82
 * @route '/tor/{id}'
 */
        torForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: tor.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    tor.form = torForm
/**
* @see \App\Http\Controllers\Images\ImagesController::queue
 * @see app/Http/Controllers/Images/ImagesController.php:92
 * @route '/queue/{id}'
 */
export const queue = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: queue.url(args, options),
    method: 'get',
})

queue.definition = {
    methods: ["get","head"],
    url: '/queue/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Images\ImagesController::queue
 * @see app/Http/Controllers/Images/ImagesController.php:92
 * @route '/queue/{id}'
 */
queue.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return queue.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Images\ImagesController::queue
 * @see app/Http/Controllers/Images/ImagesController.php:92
 * @route '/queue/{id}'
 */
queue.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: queue.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Images\ImagesController::queue
 * @see app/Http/Controllers/Images/ImagesController.php:92
 * @route '/queue/{id}'
 */
queue.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: queue.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Images\ImagesController::queue
 * @see app/Http/Controllers/Images/ImagesController.php:92
 * @route '/queue/{id}'
 */
    const queueForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: queue.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Images\ImagesController::queue
 * @see app/Http/Controllers/Images/ImagesController.php:92
 * @route '/queue/{id}'
 */
        queueForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: queue.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Images\ImagesController::queue
 * @see app/Http/Controllers/Images/ImagesController.php:92
 * @route '/queue/{id}'
 */
        queueForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: queue.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    queue.form = queueForm
/**
* @see \App\Http\Controllers\Images\ImagesController::single
 * @see app/Http/Controllers/Images/ImagesController.php:102
 * @route '/single/{single_id}'
 */
export const single = (args: { single_id: string | number } | [single_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: single.url(args, options),
    method: 'get',
})

single.definition = {
    methods: ["get","head"],
    url: '/single/{single_id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Images\ImagesController::single
 * @see app/Http/Controllers/Images/ImagesController.php:102
 * @route '/single/{single_id}'
 */
single.url = (args: { single_id: string | number } | [single_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { single_id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    single_id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        single_id: args.single_id,
                }

    return single.definition.url
            .replace('{single_id}', parsedArgs.single_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Images\ImagesController::single
 * @see app/Http/Controllers/Images/ImagesController.php:102
 * @route '/single/{single_id}'
 */
single.get = (args: { single_id: string | number } | [single_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: single.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Images\ImagesController::single
 * @see app/Http/Controllers/Images/ImagesController.php:102
 * @route '/single/{single_id}'
 */
single.head = (args: { single_id: string | number } | [single_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: single.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Images\ImagesController::single
 * @see app/Http/Controllers/Images/ImagesController.php:102
 * @route '/single/{single_id}'
 */
    const singleForm = (args: { single_id: string | number } | [single_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: single.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Images\ImagesController::single
 * @see app/Http/Controllers/Images/ImagesController.php:102
 * @route '/single/{single_id}'
 */
        singleForm.get = (args: { single_id: string | number } | [single_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: single.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Images\ImagesController::single
 * @see app/Http/Controllers/Images/ImagesController.php:102
 * @route '/single/{single_id}'
 */
        singleForm.head = (args: { single_id: string | number } | [single_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: single.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    single.form = singleForm
const ImagesController = { verification, index, customer_request, tor, queue, single }

export default ImagesController