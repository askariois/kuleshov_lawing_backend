import SortController from './SortController'
const Sort = {
    SortController: Object.assign(SortController, SortController),
}

export default Sort