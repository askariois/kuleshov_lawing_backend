import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Sort\SortController::sort
 * @see app/Http/Controllers/Sort/SortController.php:16
 * @route '/primary-sorting/{id}'
 */
export const sort = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sort.url(args, options),
    method: 'get',
})

sort.definition = {
    methods: ["get","head"],
    url: '/primary-sorting/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Sort\SortController::sort
 * @see app/Http/Controllers/Sort/SortController.php:16
 * @route '/primary-sorting/{id}'
 */
sort.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return sort.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sort\SortController::sort
 * @see app/Http/Controllers/Sort/SortController.php:16
 * @route '/primary-sorting/{id}'
 */
sort.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sort.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Sort\SortController::sort
 * @see app/Http/Controllers/Sort/SortController.php:16
 * @route '/primary-sorting/{id}'
 */
sort.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sort.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Sort\SortController::sort
 * @see app/Http/Controllers/Sort/SortController.php:16
 * @route '/primary-sorting/{id}'
 */
    const sortForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: sort.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Sort\SortController::sort
 * @see app/Http/Controllers/Sort/SortController.php:16
 * @route '/primary-sorting/{id}'
 */
        sortForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sort.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Sort\SortController::sort
 * @see app/Http/Controllers/Sort/SortController.php:16
 * @route '/primary-sorting/{id}'
 */
        sortForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sort.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    sort.form = sortForm
/**
* @see \App\Http\Controllers\Sort\SortController::storeSorting
 * @see app/Http/Controllers/Sort/SortController.php:49
 * @route '/primary-sorting/{id}/sort'
 */
export const storeSorting = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSorting.url(args, options),
    method: 'post',
})

storeSorting.definition = {
    methods: ["post"],
    url: '/primary-sorting/{id}/sort',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Sort\SortController::storeSorting
 * @see app/Http/Controllers/Sort/SortController.php:49
 * @route '/primary-sorting/{id}/sort'
 */
storeSorting.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return storeSorting.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sort\SortController::storeSorting
 * @see app/Http/Controllers/Sort/SortController.php:49
 * @route '/primary-sorting/{id}/sort'
 */
storeSorting.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSorting.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Sort\SortController::storeSorting
 * @see app/Http/Controllers/Sort/SortController.php:49
 * @route '/primary-sorting/{id}/sort'
 */
    const storeSortingForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeSorting.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Sort\SortController::storeSorting
 * @see app/Http/Controllers/Sort/SortController.php:49
 * @route '/primary-sorting/{id}/sort'
 */
        storeSortingForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeSorting.url(args, options),
            method: 'post',
        })
    
    storeSorting.form = storeSortingForm
/**
* @see \App\Http\Controllers\Sort\SortController::sort_secondary
 * @see app/Http/Controllers/Sort/SortController.php:101
 * @route '/secondary-sorting/{id}'
 */
export const sort_secondary = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sort_secondary.url(args, options),
    method: 'get',
})

sort_secondary.definition = {
    methods: ["get","head"],
    url: '/secondary-sorting/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Sort\SortController::sort_secondary
 * @see app/Http/Controllers/Sort/SortController.php:101
 * @route '/secondary-sorting/{id}'
 */
sort_secondary.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return sort_secondary.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sort\SortController::sort_secondary
 * @see app/Http/Controllers/Sort/SortController.php:101
 * @route '/secondary-sorting/{id}'
 */
sort_secondary.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sort_secondary.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Sort\SortController::sort_secondary
 * @see app/Http/Controllers/Sort/SortController.php:101
 * @route '/secondary-sorting/{id}'
 */
sort_secondary.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sort_secondary.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Sort\SortController::sort_secondary
 * @see app/Http/Controllers/Sort/SortController.php:101
 * @route '/secondary-sorting/{id}'
 */
    const sort_secondaryForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: sort_secondary.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Sort\SortController::sort_secondary
 * @see app/Http/Controllers/Sort/SortController.php:101
 * @route '/secondary-sorting/{id}'
 */
        sort_secondaryForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sort_secondary.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Sort\SortController::sort_secondary
 * @see app/Http/Controllers/Sort/SortController.php:101
 * @route '/secondary-sorting/{id}'
 */
        sort_secondaryForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sort_secondary.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    sort_secondary.form = sort_secondaryForm
const SortController = { sort, storeSorting, sort_secondary }

export default SortController